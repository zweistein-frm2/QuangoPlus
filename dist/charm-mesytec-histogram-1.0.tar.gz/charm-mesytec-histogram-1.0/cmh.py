#!/usr/bin/env python
import sys
import quango_integration

sys.exit(quango_integration.run())

